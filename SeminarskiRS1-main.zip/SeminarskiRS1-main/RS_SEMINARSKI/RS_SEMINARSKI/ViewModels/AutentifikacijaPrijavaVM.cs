﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS_SEMINARSKI.ViewModels
{
    public class AutentifikacijaPrijavaVM
    {
        public string KorisnickoIme { get; set; }
        public string Lozinka { get; set; }
        public string KorisnikID { get; set; }
    }
}
