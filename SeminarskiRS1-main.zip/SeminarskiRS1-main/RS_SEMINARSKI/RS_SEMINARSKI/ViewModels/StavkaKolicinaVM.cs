﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS_SEMINARSKI.ViewModels
{
    public class StavkaKolicinaVM
    {
        public int StavkaID { get; set; }
        public int Kolicina { get; set; }
        public string KorisnikID  { get; set; }
        public string Tip  { get; set; }

       
    }
}
