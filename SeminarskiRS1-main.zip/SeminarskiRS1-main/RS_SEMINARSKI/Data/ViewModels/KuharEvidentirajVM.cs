﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.ViewModels
{
    public class KuharEvidentirajVM
    {
        public int KuharID { get; set; }
        public string ImeKuhara { get; set; }
        public string PrezimeKuhara { get; set; }
        public float PlataKuhara { get; set; }
    }
}
