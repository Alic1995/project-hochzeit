﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.ViewModels
{
    public class KonobariEvidentirajVM
    {
        public int KonobarID { get; set; }
        public string ImeKonobara { get; set; }
        public string PrezimeKonobara { get; set; }
        public float PlataKonobara { get; set; }
       
    }
}
