﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EFModels
{
    public class Fotografija
    {
        public int FotografijaID { get; set; }
        public string  NazivStilaFotografije { get; set; }
    }
}
