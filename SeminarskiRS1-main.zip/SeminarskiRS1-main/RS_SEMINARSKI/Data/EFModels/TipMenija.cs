﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EFModels
{
    public class TipMenija
    {
        public int TipMenijaID { get; set; }

        public string NazivTipaMenija { get; set; } //u bazu spremit predjelo, gl,jelo, desret , pice
    }
    
}
