﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EFModels
{
    public class TipDekoracije
    {
        public int TipDekoracijeID { get; set; }
        public string NazivTipaDekoracije { get; set; }//Da i je za zid, sto, goste...
    }
}
