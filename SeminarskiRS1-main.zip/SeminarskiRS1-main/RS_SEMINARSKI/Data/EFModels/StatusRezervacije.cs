﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EFModels
{
   public class StatusRezervacije
    {
        public int StatusRezervacijeID { get; set; }
        public string Naziv { get; set; }
    }
}
