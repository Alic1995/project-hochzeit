﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EFModels
{
    public class TipCvijeca
    {
        public int TipCvijecaID { get; set; }
        public string NazivTipaCvijeca { get; set; } //da li je buket, za sto itd
    }
}
