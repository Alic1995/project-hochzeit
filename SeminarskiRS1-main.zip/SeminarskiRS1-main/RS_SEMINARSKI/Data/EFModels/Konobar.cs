﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EFModels
{
    public class Konobar
    {
        public int KonobarID { get; set; }
        public string  ImeKonobara { get; set; }
        public string  PrezimeKonobara { get; set; }
        public float PlataKonobara { get; set; }

    }
}
