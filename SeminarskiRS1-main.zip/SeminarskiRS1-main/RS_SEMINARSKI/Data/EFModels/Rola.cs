﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EFModels
{
    public class Rola
    {
        public int RolaID { get; set; }
        public string NazivRole { get; set; }
    }
}
