﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EFModels
{
    public class Muzika
    {
        public int MuzikaID { get; set; }
        public string NazivZanra { get; set; }
    }
}
