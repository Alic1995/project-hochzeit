﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EFModels
{
    public class Kuhar
    {
        public int KuharID { get; set; }
        public string  ImeKuhara { get; set; }
        public string  PrezimeKuhara { get; set; }
        public float PlataKuhara { get; set; }
    }
}
