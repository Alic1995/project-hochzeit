﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.EFModels
{
    public class NacinPlacanja
    {
        public int NacinPlacanjaID { get; set; }
        public string NacinPlacanjaNaziv { get; set; }
    }
}
